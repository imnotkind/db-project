#!/bin/bash

make clean && make && echo -e "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n" | ./EduBfM_Test > output.txt
echo -e "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n" | ./EduBfM_TestSolution > output_sol.txt
echo "##################################################"
echo "SHOW DIFF (if nothing shows up, then it's perfect)"
echo "##################################################"
diff output.txt output_sol.txt
make clean