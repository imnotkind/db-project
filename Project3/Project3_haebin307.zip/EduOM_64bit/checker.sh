#!/bin/bash

make clean && make && echo -e "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n" | ./EduOM_Test > output.txt
echo -e "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n" | ./EduOM_TestSolution > output_sol.txt
echo "##################################################"
echo "SHOW DIFF (if nothing shows up, then it's perfect)"
diff output.txt output_sol.txt
echo "##################################################"
make clean